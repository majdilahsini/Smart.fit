int ajouter(char cin[],char login[], char password[],int role);

