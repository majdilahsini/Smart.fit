#include <gtk/gtk.h>


void
on_suivant_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

/*on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_suivant01_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_suivant02_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_login_activate              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_login_activate              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_login_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_suivant01_login_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_suivant02_login_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_confirmer_login_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_login_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_login_clicked               (GtkButton       *button,
                                        gpointer         user_data);

                                        void
                                        on_accuei_diet_clicked                 (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_profil_diet_clicked                 (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_fchdiet_diet_clicked                (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_fichemed_diet_clicked               (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_rendez_diet_clicked                 (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_dec_diet_clicked                    (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_quit_diet_clicked                   (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_pmodifier_diet1_clicked             (GtkButton       *button,
                                                                                gpointer         user_data);

                                        void
                                        on_modifierprofil_diet_clicked         (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_changepass_diet_clicked             (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_validerp_diet_clicked               (GtkButton       *button,
                                                                                gpointer         user_data);

                                        void
                                        on_afficher1_diet_clicked              (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_afficher2_diet_clicked              (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_treeview1_diet_row_activated        (GtkTreeView     *treeview,
                                                                                GtkTreePath     *path,
                                                                                GtkTreeViewColumn *column,
                                                                                gpointer         user_data);

                                        void
                                        on_treeview2_diet_row_activated        (GtkTreeView     *treeview,
                                                                                GtkTreePath     *path,
                                                                                GtkTreeViewColumn *column,
                                                                                gpointer         user_data);

                                        void
                                        on_treeview3_diet_row_activated        (GtkTreeView     *treeview,
                                                                                GtkTreePath     *path,
                                                                                GtkTreeViewColumn *column,
                                                                                gpointer         user_data);

                                        void
                                        on_ajouterfiche_diet_clicked           (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_suprimerfiche_diet_clicked          (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_modifierfiche_diet_clicked          (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_dialog_diet_show                    (GtkWidget       *widget,
                                                                                gpointer         user_data);

                                        void
                                        on_treeview3_diet_row_activated        (GtkTreeView     *treeview,
                                                                                GtkTreePath     *path,
                                                                                GtkTreeViewColumn *column,
                                                                                gpointer         user_data);

                                        void
                                        on_treeview4_diet_row_activated        (GtkTreeView     *treeview,
                                                                                GtkTreePath     *path,
                                                                                GtkTreeViewColumn *column,
                                                                                gpointer         user_data);

                                        void
                                        on_afficher_fichesmeddiet_clicked      (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_toolbutton3_clicked                 (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_affichercommun_diet_clicked         (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_msg_diet_clicked                    (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_boiterecep_diet_clicked             (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_messagenvoy_diet_clicked            (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_nouvmesg_diet_clicked               (GtkToolButton   *toolbutton,
                                                                                gpointer         user_data);

                                        void
                                        on_chargerrendez_diet_clicked          (GtkButton       *button,
                                                                                gpointer         user_data);

                                        void
                                        on_validerrend_diet_clicked            (GtkButton       *button,
                                                                                gpointer         user_data);

                                        void
                                        on_combobox1_d_changed                 (GtkComboBox     *combobox,
                                                                                gpointer         user_data);

                                        void
                                        on_treeview15_dd_row_activated         (GtkTreeView     *treeview,
                                                                                GtkTreePath     *path,
                                                                                GtkTreeViewColumn *column,
                                                                                gpointer         user_data);

                                        void
                                        on_suprimerrdv_dd_clicked              (GtkButton       *button,
                                                                                gpointer         user_data);
                                                                                void
                                                                                on_button1_clicked                     (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_button_ay2_clicked                  (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_buttonay_3_clicked                  (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);



                                                                                void
                                                                                on_checkbutton_show_ay1_toggled        (GtkToggleButton *togglebutton,
                                                                                                                        gpointer         user_data);





                                                                                void
                                                                                on_button_ay11_clicked                 (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_button_ay5_leave                    (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);





                                                                                void
                                                                                on_button_ay20_clicked                 (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_button_ay30_clicked                 (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_button_ay6_clicked                  (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_button_ay15_clicked                 (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);




                                                                                void
                                                                                on_treeview1_row_activated             (GtkWidget    *objet_graphique,
                                                                                                                        GtkTreePath     *path,
                                                                                                                        GtkTreeViewColumn *column,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_button_calen_re_clicked             (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);
                                                                                void
                                                                                on_button_decon_cal_clicked            (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);



                                                                                void
                                                                                on_button_aycal_clicked                (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);


                                                                                void
                                                                                on_button_ay201_clicked                (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_button_ay130_clicked                (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_button2_clicked                     (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_combobox_ay100_changed              (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);
                                                                                void
                                                                                on_button_ay14_clicked                 (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_button_ay202_clicked                (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);

                                                                                void
                                                                                on_button_ay604_clicked                (GtkWidget       *objet_graphique,
                                                                                                                        gpointer         user_data);
                                                                                void
                                                                                on_treeview2_row_activated             (GtkWidget    *objet_graphique,
                                                                                                                        GtkTreePath     *path,
                                                                                                                        GtkTreeViewColumn *column,
                                                                                                                        gpointer         user_data);
