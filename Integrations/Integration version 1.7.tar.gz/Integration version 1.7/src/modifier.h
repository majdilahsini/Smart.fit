void modifier(char cin[],char login[],char password[]);
void modifier_calendrier(char date[],char heure1[],char heure2[],char evenement[]);
