#include <gtk/gtk.h>

void select_page(GtkToolButton *button,int page, char name[20]);
