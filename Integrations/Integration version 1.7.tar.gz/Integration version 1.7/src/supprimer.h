void supprimer(char cin[]);
void supprimer_calendrier(char date[50]);
