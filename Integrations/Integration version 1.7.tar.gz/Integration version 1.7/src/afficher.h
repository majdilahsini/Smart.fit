
void afficher(GtkWidget *pListView,int role);
