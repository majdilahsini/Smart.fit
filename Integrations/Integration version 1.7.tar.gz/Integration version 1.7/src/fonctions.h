int verifier_login (char login[], char password[], int t[], char CIN[8]);
